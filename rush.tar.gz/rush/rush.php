<?php

define('USER_AGENT', [
    0 => [
        [
            'info' => '{"device":"Mobile","language":"en_US","engine":"WebKit","browser":"Safari","os":"iOS","osVersion":"13.2.3","version":"13.0.3"}',
            'platform' => 2
        ],
        'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1'
    ],
    1 => [
        [
            'info' => '{"device":"Mobile","language":"zh_CN","engine":"WebKit","browser":"QQBrowser","os":"iOS","osVersion":"12.4.6","version":"10.4.0"}',
            'platform' => 2
        ],
        'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1'
    ],
    2 => [
        [
            'info' => '{"device":"PC","language":"zh_CN","engine":"WebKit","browser":"360EE","os":"Windows","osVersion":"10.0","version":""}',
            'platform' => 1
        ],
        'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36',
    ],
]);

require_once 'libraries/Game.php';

function getCurrentRound($params)
{
    $url = $params['apiURL'];
    $data = [
        'oid'          => $params['oid'],
        'game_code'    => $params['game_code'],
    ];
    $proxy = explode(':', $params['proxy']);
    $proxyAuth = $params['proxyUserPass'];
    $userAgent = $params['userAgent'];
    $agentArr = USER_AGENT;
    if ( ! isset($agentArr[$userAgent]))
    {
        exit(json_encode(['code'=>1, 'info'=>'错误的伪装代号!']));
    }
    $response = curl($url.'/getinfo/game', $data, $proxy, $proxyAuth, $userAgent);
    if ($response['result'] == FALSE)
    {
        exit(json_encode(['code'=>1, 'info'=>'网络错误!'.$response['error']]));
    }
    $resp = json_decode($response['data'], TRUE);
    if (isset($resp['msg']) && $resp['msg'] == 4001)
    {
        exit(json_encode($resp));
    }
    if ( ! isset($resp['next']['round']))
    {
        exit(json_encode(['code'=>1, 'info'=>'获取期号错误!'.json_encode($resp)]));
    }
    return $resp;
}

function login($params)
{
    $data = [];
    $url = $params['apiURL'];
    $proxy = explode(':', $params['proxy']);
    $proxyAuth = $params['proxyUserPass'];
    $userAgent = $params['userAgent'];
    $agentArr = USER_AGENT;
    if ( ! isset($agentArr[$userAgent]))
    {
        exit(json_encode(['code'=>1, 'info'=>'错误的伪装代号!']));
    }
    if ($params['onlineMode'] == 'login')
    {
        $url .= '/user/signin';
        $data['username'] = $params['username'];
        $data['password'] = $params['password'];
        $data['deviceInfo'] = $agentArr[$userAgent][0]['info'];
        $data['platform'] = $agentArr[$userAgent][0]['platform'];
        $response = curl($url, $data, $proxy, $proxyAuth, $agentArr[1]);
    }
    else
    {
        $url .= '/getinfo/money';
        $data['oid'] = $params['oid'];
        $data['sports'] = 1;
        $response = curl($url, $data, $proxy, $proxyAuth, $userAgent[1]);
    }
    if ($response['result'] == TRUE)
    {
        echo json_encode(json_decode($response['data']));
    }
    else
    {
        echo json_encode(['code'=>1, 'info'=>$response['error']]);
    }
}

function rush($params)
{
    $userAgent = $params['userAgent'];
    $oid = $params['oid'];
    $agentArr = USER_AGENT;
    if ( ! isset($agentArr[$userAgent]))
    {
        exit(json_encode(['code'=>1, 'info'=>'错误的伪装代号!']));
    }
    if (empty($params['bet_money']) || $params['bet_money'] < 5)
    {
        exit(json_encode(['code'=>1, 'info'=>'下注金额必须大于5!']));
    }
    $bet_mode = isset($params['betMode']) ? $params['betMode'] : 0;
    $run_mode = isset($params['run_mode']) ? $params['run_mode'] : 0;
    $cheat = $params['cheat'];
    is_array($cheat) || $cheat = [];
    $game = new Game();
    $bet_round = $params['currentRound'];
    $current_round = getCurrentRound($params);
    $real_ticking = $current_round['next']['closetime'] - $current_round['next']['timestap'];
    $ticking = $real_ticking - 5 > 3 ? $real_ticking - 5 : $real_ticking;
    if ($real_ticking < 2)
    {
        exit(json_encode(['code'=>1, 'msg'=>5002, 'info'=>$current_round['next']['round'].' 封盘!', 'data'=>['ticking'=>mt_rand(0, abs($ticking))]]));
    }
    if ($bet_round == '')
    {
        $bet_round = $current_round['next']['round'];
    }
    $proxy = explode(':', $params['proxy']);
    $proxyAuth = $params['proxyUserPass'];
    $in = $game->init($bet_round, $params['game_code'], $params['bet_money'], $bet_mode, $run_mode, $cheat);
    if (empty($in))
    {
        exit(json_encode(['code'=>1, 'msg'=>3003, 'info'=>'参数错误!']));
    }
    // 合并下注和辅助参数
    $data = array_merge(['oid'=>$oid,'token'=>'', 'game_code'=>$params['game_code'], 'round'=>$bet_round], $in);
    $url = $params['apiURL'];
    sleep(mt_rand(1,5));
    $response = curl($url.'/inup', $data, $proxy, $proxyAuth, $userAgent);
    if ($response['result'] == FALSE)
    {
        exit(json_encode(['code'=>1, 'info'=>'网络错误,下注失败!'.$response['error']]));
    }
    $resp = json_decode($response['data'], TRUE);
    if ( ! is_array($resp))
    {
        exit(json_encode(['code'=>1, 'info'=>'下注返回数据不正确!'.$response['data']]));
    }
    if (isset($resp['msg']) && $resp['msg'] != 2006)
    {
        if (in_array($resp['msg'], [4001,5003,5009]))
        {
            if ($resp['msg'] == 5003) $resp['data']['ticking'] = mt_rand(15, 40);
            exit(json_encode($resp));
        }
    }
    if (isset($resp['logs']))
    {
        $resp = $resp['logs'];
    }
    exit(json_encode(['code'=>0, 'info'=>'下注成功!', 'data'=>['lastBetRound'=>$bet_round, 'ticking'=>abs(mt_rand($real_ticking-mt_rand(1,10), $real_ticking+mt_rand(1,10))), 'list'=>$resp, 'time'=>date('H:i:s')]]));
}

function curl($url, $data, $proxy, $proxyAuth, $userAgent)
{
    if ( ! isset($proxy[0]) || ! $proxy[0] || ! isset($proxy[1]) || ! $proxy[1] || ! $proxyAuth)
    {
        return ['result'=>FALSE, 'error'=>'必须使用代理'];
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_PROXY, $proxy[0]);
    curl_setopt($ch, CURLOPT_PROXYPORT, $proxy[1]);
    curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP_1_0);
    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyAuth);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
    $result = curl_exec($ch);
    $error = curl_error($ch);
    if ($error)
    {
        return ['result'=>FALSE, 'error'=>$error];
    }
    return ['result'=>TRUE, 'data'=>$result];
}

function handle($requestParams)
{
    header('Content-Type: application/json; charset=utf8');
    switch ($requestParams['code'])
    {
        case 'login':
            login($requestParams['params']);
            break;
        case 'rush':
            rush($requestParams['params']);
            break;
        default:
            break;
    }
}

$requestBody = file_get_contents("php://input");
$requestParams = json_decode($requestBody, TRUE);

handle($requestParams);