<?php

class Game
{

    private $pk10 = [171,240,260];
    private $ssc = [46,250];

    private $pk10Case = [
        0 => ['ip_3001_1','ip_3001_2','ip_3001_3','ip_3001_4','ip_3001_5','ip_3001_6','ip_3001_7','ip_3001_8','ip_3001_9','ip_3001_10'],
        1 => ['ip_3002_1','ip_3002_2','ip_3002_3','ip_3002_4','ip_3002_5','ip_3002_6','ip_3002_7','ip_3002_8','ip_3002_9','ip_3002_10']
    ];

    private $sscCase = [
        0 => ['ip_1000_0','ip_1000_2','ip_1000_3','ip_1000_4','ip_1000_5','ip_1000_6','ip_1000_7','ip_1000_8','ip_1000_9'],
        1 => ['ip_1001_0','ip_1001_2','ip_1001_3','ip_1001_4','ip_1001_5','ip_1001_6','ip_1001_7','ip_1001_8','ip_1001_9'],
        2 => [
            ['ip_1000_1','ip_1001_1','ip_1002_1','ip_1003_1','ip_1004_1'],
            ['ip_1000_2','ip_1001_2','ip_1002_2','ip_1003_2','ip_1004_2'],
            ['ip_1000_3','ip_1001_3','ip_1002_3','ip_1003_3','ip_1004_3'],
            ['ip_1000_4','ip_1001_4','ip_1002_4','ip_1003_4','ip_1004_4'],
            ['ip_1000_5','ip_1001_5','ip_1002_5','ip_1003_5','ip_1004_5'],
            ['ip_1000_6','ip_1001_6','ip_1002_6','ip_1003_6','ip_1004_6'],
            ['ip_1000_7','ip_1001_7','ip_1002_7','ip_1003_7','ip_1004_7'],
            ['ip_1000_8','ip_1001_8','ip_1002_8','ip_1003_8','ip_1004_8'],
            ['ip_1000_9','ip_1001_9','ip_1002_9','ip_1003_9','ip_1004_9'],
            ['ip_1000_10','ip_1001_10','ip_1002_10','ip_1003_10','ip_1004_10'],
        ],

    ];

    public function init($current_round, $game_code, $bet_money, $bet_mode, $run_mode, $cheat)
    {
        if (in_array($game_code, $this->pk10))
        {
            return $this->pk10($current_round, $bet_money, $bet_mode, $run_mode, $cheat);
        }
        else if (in_array($game_code, $this->ssc))
        {
            return $this->ssc($current_round, $bet_money, $bet_mode, $run_mode, $cheat);
        }
        return FALSE;
    }

    private function pk10($current_round, $bet_money, $bet_mode, $run_mode, $cheat)
    {
        $position = [];
        $in = [];
        if (in_array($bet_mode, [0,1]))
        {
            $in['type_code'] = 4;
            $arr = isset($this->pk10Case[$bet_mode]) ? $this->pk10Case[$bet_mode] : $this->pk10Case[0];
            if (in_array($run_mode, [1,2]) && isset($cheat[$current_round]))
            {
                $number = explode(',', $cheat[$current_round]);
                // 取得中奖号码目标位置
                $n = $number[$bet_mode];
                // 盈利
                if ($run_mode == 1)
                {
                    foreach ($arr as $v)
                    {
                        if (substr($v, -1) == $n)
                        {
                            $position[] = $v;
                            break;
                        }
                    }
                }
                // 亏损 必须砍掉会中的号码再随机
                else
                {
                    foreach ($arr as $k => $v)
                    {
                        if (substr($v, -1) == $n)
                        {
                            unset($arr[$k]);
                            break;
                        }
                    }
                }
            }
            // 小过4个号码 继续取
            while (count($position) < 4)
            {
                $index = array_rand($arr);
                if ( ! in_array($arr[$index], $position))
                {
                    $position[] = $arr[$index];
                }
            }
            foreach ($position as $item)
            {
                $in[$item] = $bet_money;
            }
            return $in;
        }
        return [];
    }

    private function ssc($current_round, $bet_money, $bet_mode, $run_mode, $cheat)
    {
        $position = [];
        $in = [];
        if (in_array($bet_mode, [0,1]))
        {
            $in['type_code'] = 1;
            $arr = isset($this->sscCase[$bet_mode]) ? $this->sscCase[$bet_mode] : $this->sscCase[0];
            if (in_array($run_mode, [1,2]) && isset($cheat[$current_round]))
            {
                $number = explode(',', $cheat[$current_round]);
                // 取得中奖号码目标位置
                $n = $number[$bet_mode];
                // 盈利
                if ($run_mode == 1)
                {
                    foreach ($arr as $v)
                    {
                        if (substr($v, -1) == $n)
                        {
                            $position[] = $v;
                            break;
                        }
                    }
                }
                // 亏损 必须砍掉会中的号码再随机
                else
                {
                    foreach ($arr as $k => $v)
                    {
                        if (substr($v, -1) == $n)
                        {
                            unset($arr[$k]);
                            break;
                        }
                    }
                }
            }
            // 小过5个号码 继续取
            while (count($position) < 5)
            {
                $index = array_rand($arr);
                if ( ! in_array($arr[$index], $position))
                {
                    $position[] = $arr[$index];
                }
            }
            foreach ($position as $item)
            {
                $in[$item] = $bet_money;
            }
            return $in;

        }
        else if ($bet_mode == 2)
        {
            $in['type_code'] = 1;
            $number = explode(',', $cheat[$current_round]);
            $arr = [];
            // 取得中奖号码目标位置
            if (in_array($run_mode, [1,2]) && isset($cheat[$current_round]))
            {
                if ($run_mode == 1)
                {
                    // 随便取一个位置看开奖号码
                    $target = mt_rand(0, 4);
                    $n = $number[$target] - 1;
                    $arr = $this->sscCase[2][$n];
                }
                else
                {
                    $temp = $this->sscCase[2];
                    foreach ($temp as $k => $v)
                    {
                        if ( ! in_array($v, $number))
                        {
                            $arr = $v;
                            break;
                        }
                    }
                }
                foreach ($arr as $v)
                {
                    $in[$v] = $bet_money;
                }
                return $in;
            }
            else
            {
                $target = mt_rand(0, 9);
                foreach ($this->sscCase[2][$target] as $v)
                {
                    $in[$v] = $bet_money;
                }
                return $in;
            }
        }
        return [];
    }

}