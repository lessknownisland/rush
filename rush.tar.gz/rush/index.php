<?php

require_once 'views/flush.html';